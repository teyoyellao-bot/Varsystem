package varsystem.model;

import java.io.Serializable;
import java.time.LocalDateTime;

public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    public String name, email, username, password,
            phone = "", location = "", vehicle = "",
            birthday = "",
            license = "Not added yet",
            role = "User", status = "Active",
            shop = "", avatar = "";

    public LocalDateTime joined = LocalDateTime.now();

    public boolean notif = true, loc = true, remind = true;
}