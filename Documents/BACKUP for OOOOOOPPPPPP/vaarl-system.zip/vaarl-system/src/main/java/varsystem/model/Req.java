
package varsystem.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import varsystem.data.DB;

/**
 * A vehicle assistance (service) request.
 * Supports saving and restoring requests after restarting the application.
 * Includes customer GPS location and shop-specific location sharing.
 */
public class Req implements Serializable {

    private static final long serialVersionUID = 1L;

    public String id, uemail, uname, uphone, vehicle, problem,
            location, details = "", shop,
            status = "Pending", mechanic = "",
            payment = "Cash / GCash";

    public int fee, travel;

    public LocalDateTime submitted = LocalDateTime.now(),
            accepted, completed;

    // Customer GPS location for this specific request
    public double userLatitude = Double.NaN;
    public double userLongitude = Double.NaN;

    // Customer permission to share location with the requested shop
    public boolean shareLocation = false;

    /**
     * Checks whether the request contains valid GPS coordinates.
     */
    public boolean hasUserLocation() {
        return Double.isFinite(userLatitude)
                && Double.isFinite(userLongitude)
                && userLatitude >= -90
                && userLatitude <= 90
                && userLongitude >= -180
                && userLongitude <= 180;
    }

    /**
     * Checks whether the request is still active.
     */
    public boolean isActive() {
        return status != null
                && ("Pending".equalsIgnoreCase(status)
                || "Accepted".equalsIgnoreCase(status)
                || "On Going".equalsIgnoreCase(status));
    }

    /**
     * The customer's saved Location Sharing preference is also enforced for
     * existing requests. Turning the preference OFF hides their coordinates
     * without deleting the request's saved address or coordinates.
     */
    private boolean customerLocationSharingEnabled() {
        if (uemail == null || uemail.isBlank()) {
            return false;
        }
        for (User account : DB.users) {
            if (account != null
                    && account.email != null
                    && account.email.equalsIgnoreCase(uemail)
                    && "User".equalsIgnoreCase(account.role)) {
                return account.loc;
            }
        }
        // Fail closed when the account preference cannot be verified.
        return false;
    }


    /**
     * Checks whether this request's customer location
     * can be displayed on the specified shop's dashboard.
     */
    public boolean canShareLocationWith(String shopName) {
        return shareLocation
                && hasUserLocation()
                && isActive()
                && customerLocationSharingEnabled()
                && shop != null
                && shopName != null
                && !shop.isBlank()
                && !shopName.isBlank()
                && shop.trim().equalsIgnoreCase(shopName.trim());
    }
}