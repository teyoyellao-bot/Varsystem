
package varsystem.ui.auth;

import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Locale;
import varsystem.data.DB;
import varsystem.model.User;
import varsystem.service.EmailOtpService;
import varsystem.service.PasswordSecurity;
import static varsystem.ui.components.Dialogs.*;
import varsystem.ui.components.Dialogs.PasswordInput;

public final class ForgotPasswordDialog {

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final long OTP_LIFETIME_MS = 5 * 60 * 1000L;
    private static final long RESEND_COOLDOWN_MS = 60 * 1000L;
    private static final int MAX_OTP_ATTEMPTS = 5;

    private ForgotPasswordDialog() { }

    public static void show() {

        // STEP 1: COLLECT ACCOUNT DETAILS
        String[] details = form(
            "Forgot Password - Verify Your Account",
            new String[]{
                "Registered Email",
                "Account Type",
                "Full Name",
                "Username",
                "Birthday (YYYY-MM-DD)"
            },
            new Object[]{
                "",
                new String[]{"Vehicle Owner / User", "Repair Shop"},
                "", "", ""
            }
        );

        if (details == null) return;

        String email = clean(details[0]);
        String accountType = clean(details[1]);
        String fullName = normalize(details[2]);
        String username = clean(details[3]);
        String birthdayText = clean(details[4]);

        if (email.isEmpty() || fullName.isEmpty()
                || username.isEmpty() || birthdayText.isEmpty()) {
            err("Please complete all account verification fields.");
            return;
        }

        LocalDate birthday;
        try {
            birthday = LocalDate.parse(birthdayText);
        } catch (DateTimeParseException ex) {
            err("Please enter your birthday using YYYY-MM-DD.");
            return;
        }

        // STEP 2: VERIFY ACCOUNT INFORMATION
        User account = DB.users.stream()
            .filter(u -> u != null
                && u.email != null
                && u.email.equalsIgnoreCase(email))
            .findFirst()
            .orElse(null);

        boolean selectedShop = "Repair Shop".equals(accountType);
        boolean actualShop = account != null
                && ("Shop Manager".equalsIgnoreCase(account.role)
                    || "Shop".equalsIgnoreCase(account.role));

        boolean hasSavedBirthday = account != null
                && account.birthday != null
                && !account.birthday.isBlank();

        boolean birthdayMatches = !hasSavedBirthday
                || account.birthday.equals(birthday.toString());

        boolean accountDetailsMatch = account != null
                && account.name != null
                && normalize(account.name).equals(fullName)
                && account.username != null
                && account.username.equalsIgnoreCase(username)
                && birthdayMatches
                && selectedShop == actualShop;

        if (!accountDetailsMatch) {
            err("We could not verify the account details. Check your information or use Admin-Assisted Recovery.");
            return;
        }

        // STEP 3: CHOOSE EMAIL OTP OR ADMIN-ASSISTED RECOVERY
        if (!hasSavedBirthday) {
            msg("This is an older account without a saved birthday. "
                + "For safety, this account must be reviewed by Admin.");
            submitAdminRecovery(account);
            return;
        }

        boolean canAccessEmail = ask(
            "ACCOUNT DETAILS MATCH\n\n"
            + "Account: " + account.name + "\n"
            + "Type: " + (actualShop ? "Repair Shop" : "Vehicle Owner / User")
            + "\n\nCan you access this registered email?\n"
            + account.email
            + "\n\nChoose Yes to receive a verification code."
        );

        if (!canAccessEmail) {
            submitAdminRecovery(account);
            return;
        }

        // STEP 4: SEND OTP
        String otp = generateOtp();
        if (!EmailOtpService.sendOtp(account.email, otp)) {
            boolean useAdminRecovery = ask(
                "VAARL could not send the email verification code.\n\n"
                + "Check the email service configuration or submit an "
                + "Admin-Assisted Recovery request instead.\n\n"
                + "Submit a request to Admin?"
            );

            if (useAdminRecovery) {
                submitAdminRecovery(account);
            } else {
                err("Password was not changed. Please try again later.");
            }
            return;
        }

        long sentAt = System.currentTimeMillis();
        long expiresAt = sentAt + OTP_LIFETIME_MS;
        int attempts = 0;
        boolean verified = false;

        msg("A 6-digit verification code was sent to your registered email. It expires in 5 minutes.");

        // STEP 5: VERIFY OTP; LIMIT TO FIVE ATTEMPTS
        while (attempts < MAX_OTP_ATTEMPTS) {

            if (System.currentTimeMillis() > expiresAt) {
                err("The verification code has expired. Please restart Forgot Password.");
                return;
            }

            String[] codeInput = form(
                "Email OTP Verification",
                new String[]{"6-digit verification code"},
                new Object[]{""}
            );

            if (codeInput == null) return;

            String enteredCode = clean(codeInput[0]);

            if (System.currentTimeMillis() > expiresAt) {
                err("The verification code expired while the form was open. Please restart Forgot Password.");
                return;
            }

            if (enteredCode.equals(otp)) {
                verified = true;
                break;
            }

            attempts++;
            int remaining = MAX_OTP_ATTEMPTS - attempts;
            err("Incorrect verification code. Remaining attempts: " + remaining);

            if (attempts >= MAX_OTP_ATTEMPTS) break;

            if (ask("Do you want to resend a new verification code?")) {
                long elapsed = System.currentTimeMillis() - sentAt;
                if (elapsed < RESEND_COOLDOWN_MS) {
                    long seconds = (RESEND_COOLDOWN_MS - elapsed + 999) / 1000;
                    err("Please wait " + seconds + " seconds before requesting another code.");
                } else {
                    String newOtp = generateOtp();
                    if (EmailOtpService.sendOtp(account.email, newOtp)) {
                        otp = newOtp;
                        sentAt = System.currentTimeMillis();
                        expiresAt = sentAt + OTP_LIFETIME_MS;
                        msg("A new verification code has been sent.");
                    } else {
                        err("Unable to resend the verification code.");
                    }
                }
            }
        }

        if (!verified) {
            err("Too many incorrect attempts or verification was not completed. Please start again.");
            return;
        }

        // STEP 6: SET NEW PASSWORD
        String[] passwords = form(
            "Create a New Password",
            new String[]{"New Password", "Confirm New Password"},
            new Object[]{new PasswordInput(), new PasswordInput()}
        );

        if (passwords == null) return;

        String newPassword = passwords[0];
        String confirmPassword = passwords[1];

        if (newPassword == null || confirmPassword == null
                || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            err("Please complete both password fields.");
            return;
        }

        int minimumLength = DB.intS(
            "Security.Minimum Password Length", 8
        );

        if (newPassword.length() < minimumLength) {
            err("Password must contain at least " + minimumLength + " characters.");
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            err("Passwords do not match.");
            return;
        }

        if (PasswordSecurity.verify(newPassword, account.password)) {
            err("Your new password must be different from your current password.");
            return;
        }

        // STEP 7: SAVE HASHED PASSWORD
        account.password = PasswordSecurity.hash(newPassword);
        DB.log("Password reset completed for account: " + account.username);
        DB.saveAllData();

        msg("Your password has been reset successfully. You can now log in with your new password.");
    }

    private static void submitAdminRecovery(User account) {

        String message =
            "ACCOUNT RECOVERY REQUEST\n\n"
            + "The account holder reports that they cannot access the registered email.\n"
            + "Requested account type: "
            + ("Shop Manager".equalsIgnoreCase(account.role)
                ? "Repair Shop" : "Vehicle Owner / User")
            + "\nRegistered username: " + account.username
            + "\nRegistered phone: "
            + (account.phone == null || account.phone.isBlank()
                ? "Not provided" : account.phone)
            + "\n\nAdmin action required: verify the requester using the "
            + "shop's submitted ID / existing account records and contact "
            + "the registered phone number before authorizing a password reset.\n"
            + "Do not send or request the current password.";

        boolean sent = DB.sendSupportMessage(
            account.name,
            account.email,
            account.role,
            message
        );

        if (sent) {
            msg("Your Admin-Assisted Recovery request has been submitted. "
                + "Please wait for the Admin to review it in the Support Inbox. "
                + "Your password has not been changed yet.");
        } else {
            err("Unable to submit your recovery request. Please contact the system administrator.");
        }
    }

    private static String generateOtp() {
        return String.format(Locale.ROOT, "%06d", RANDOM.nextInt(1_000_000));
    }

    private static String clean(String value) {
        return value == null ? "" : value.trim();
    }

    private static String normalize(String value) {
        return clean(value).replaceAll("\\s+", " ")
                .toLowerCase(Locale.ROOT);
    }
}

