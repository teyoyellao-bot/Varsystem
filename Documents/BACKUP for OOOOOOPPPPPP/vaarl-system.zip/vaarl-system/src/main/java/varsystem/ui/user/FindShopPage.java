
package varsystem.ui.user;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import varsystem.data.DB;
import varsystem.model.Shop;
import varsystem.service.LocationService;
import varsystem.service.LocationService.Location;
import varsystem.ui.components.MapPanel;
import static varsystem.ui.components.Ui.lbl;
import static varsystem.ui.frame.MainFrame.page;
import static varsystem.ui.theme.Theme.NAVY;

public final class FindShopPage {

    private FindShopPage() { }

    // DARK BLUE GRADIENT COLORS
    private static final Color GRADIENT_DARK =
        new Color(0x00, 0x16, 0x38);

    private static final Color GRADIENT_MID =
        new Color(0x08, 0x2D, 0x60);

    private static final Color GRADIENT_LIGHT =
        new Color(0x10, 0x4B, 0x85);

    private static final Color GRADIENT_BORDER =
        new Color(0x3A, 0x79, 0xB8);

    private static final Color LIGHT_TEXT =
        new Color(0xD9, 0xEA, 0xFF);

    static double radius() {
        return DB.intS("General.Default Request Radius", 25);
    }

    public static JComponent build() {

        JComponent[] pg = page(
            "Find Shop",
            "Search nearby repair shops and request assistance."
        );

        // ORIGINAL BODY
        JPanel originalBody = (JPanel) pg[1];

        // FULL PAGE GRADIENT
        PageGradientPanel body =
            new PageGradientPanel(new BorderLayout(10, 0));

        body.setBorder(new EmptyBorder(0, 0, 0, 0));

        pg[0].remove(originalBody);
        pg[0].add(body, BorderLayout.CENTER);
        pg[0].setOpaque(false);

        JTextField q = new JTextField();
        MapPanel map = new MapPanel();

        // SHOP CARDS CONTAINER
        JPanel cards = new JPanel();
        cards.setLayout(new BoxLayout(cards, BoxLayout.Y_AXIS));
        cards.setOpaque(false);

        // LOCATE BUTTON
        GradientButton locateButton =
            new GradientButton("Locate Me");

        locateButton.addActionListener(
            e -> locateLaptop(map, locateButton)
        );

        // SEARCH AND DISPLAY SHOPS
        Runnable fill = () -> {

            String search = q.getText().toLowerCase().trim();
            double rad = radius();

            List<Shop> res = DB.shops.stream()
                .filter(x -> x != null
                    && "Active".equals(x.status)
                    && x.dist <= rad
                    && (search.isEmpty()
                        || (x.name != null
                            && x.name.toLowerCase().contains(search))
                        || (x.location != null
                            && x.location.toLowerCase().contains(search))
                        || (x.services != null
                            && x.services.stream()
                                .anyMatch(v -> v != null
                                    && v.toLowerCase().contains(search)))
                    )
                )
                .sorted(Comparator.comparingDouble(x -> x.dist))
                .collect(Collectors.toList());

            List<Shop> mappedShops = res.stream()
                .filter(Shop::hasLocation)
                .collect(Collectors.toList());

            map.setShops(mappedShops);

            cards.removeAll();

            if (res.isEmpty()) {

                cards.add(lbl(
                    "No repair shops found.",
                    13,
                    false,
                    LIGHT_TEXT
                ));

            } else {

                for (Shop shop : res) {
                    cards.add(shopCard(shop));
                    cards.add(Box.createVerticalStrut(10));
                }
            }

            if (mappedShops.isEmpty() && !res.isEmpty()) {

                cards.add(lbl(
                    "Map locations are not available for these shops yet.",
                    12,
                    false,
                    LIGHT_TEXT
                ));
            }

            cards.revalidate();
            cards.repaint();
        };

        map.onPick = ShopDetailDialog::show;

        // SEARCH FIELD
        q.setFont(
            new Font("SansSerif", Font.PLAIN, 14)
        );

        q.setForeground(NAVY);
        q.setCaretColor(NAVY);
        q.setBackground(Color.WHITE);

        q.setBorder(new CompoundBorder(
            new LineBorder(GRADIENT_BORDER, 2, true),
            new EmptyBorder(6, 10, 6, 10)
        ));

        q.addActionListener(e -> fill.run());

        // SEARCH BUTTON
        GradientButton sb =
            new GradientButton("Search");

        sb.addActionListener(e -> fill.run());

        JPanel sr = new JPanel(
            new BorderLayout(10, 0)
        );

        sr.setOpaque(false);
        sr.add(q, BorderLayout.CENTER);
        sr.add(sb, BorderLayout.EAST);

        // TOP SEARCH AREA
        JPanel north = new JPanel(
            new BorderLayout(0, 6)
        );

        north.setOpaque(false);
        north.add(sr, BorderLayout.NORTH);

        north.setBorder(
            new EmptyBorder(0, 0, 8, 0)
        );

        // MAP AREA WITH DARK BLUE GRADIENT
        GradientPanel left = new GradientPanel(
            new BorderLayout(0, 8),
            GRADIENT_DARK,
            GRADIENT_LIGHT,
            16
        );

        left.setBorder(
            new EmptyBorder(8, 8, 8, 8)
        );

        left.add(north, BorderLayout.NORTH);

        // KEEP ORIGINAL MAP COMPONENT
        map.setBorder(
            new LineBorder(GRADIENT_BORDER, 2, true)
        );

        left.add(map, BorderLayout.CENTER);

        // LOCATE ME BUTTON BELOW MAP - RIGHT SIDE
        JPanel locatePanel = new JPanel(
            new FlowLayout(FlowLayout.RIGHT, 0, 0)
        );

        locatePanel.setOpaque(false);
        locatePanel.add(locateButton);

        left.add(locatePanel, BorderLayout.SOUTH);

        // SHOP LIST SCROLL PANE
        JScrollPane sp = new JScrollPane(cards);

        sp.setBorder(
            new LineBorder(GRADIENT_BORDER, 2, true)
        );

        sp.setPreferredSize(
            new Dimension(320, 100)
        );

        sp.getViewport().setBackground(GRADIENT_DARK);
        sp.getViewport().setOpaque(true);

        sp.setOpaque(false);
        sp.getVerticalScrollBar().setUnitIncrement(16);

        cards.setBorder(
            new EmptyBorder(10, 10, 10, 10)
        );

        // RIGHT SIDE GRADIENT BACKGROUND
        GradientPanel east = new GradientPanel(
            new BorderLayout(),
            GRADIENT_DARK,
            GRADIENT_MID,
            16
        );

        east.setBorder(
            new EmptyBorder(8, 8, 8, 8)
        );

        east.add(sp, BorderLayout.CENTER);

        // ADD PANELS TO FULL GRADIENT BODY
        body.add(left, BorderLayout.CENTER);
        body.add(east, BorderLayout.EAST);

        // INITIAL LOAD
        fill.run();

        // INITIAL LOCATION DETECTION
        locateLaptop(
            map,
            locateButton
        );

        return pg[0];
    }

    // GET LAPTOP LOCATION
    private static void locateLaptop(
            MapPanel map,
            JButton locateButton) {

        // CHECK LOCATION SHARING PREFERENCE
        if (varsystem.data.Session.ME != null
                && !varsystem.data.Session.ME.loc) {

            JOptionPane.showMessageDialog(
                SwingUtilities.getWindowAncestor(map),
                "Location Sharing is turned OFF in your Preferences.\n"
                    + "Turn it ON to use location-based services.",
                "Location Sharing Disabled",
                JOptionPane.INFORMATION_MESSAGE
            );

            if (locateButton != null) {
                locateButton.setEnabled(true);
            }

            return;
        }

        if (locateButton != null) {
            locateButton.setEnabled(false);
        }

        new SwingWorker<Location, Void>() {

            @Override
            protected Location doInBackground() throws Exception {
                return LocationService.getCurrentLocation();
            }

            @Override
            protected void done() {

                try {

                    Location location = get();

                    map.setMyLocation(
                        location.latitude,
                        location.longitude
                    );

                } catch (Exception ex) {

                    Throwable cause =
                        ex.getCause() == null ? ex : ex.getCause();

                    String message = cause.getMessage();

                    JOptionPane.showMessageDialog(
                        SwingUtilities.getWindowAncestor(map),
                        "Unable to detect the laptop location.\n\n"
                            + (message == null
                                ? cause.getClass().getSimpleName()
                                : message)
                            + "\n\nCheck your internet connection and try again."
                            + "\nNote: this version estimates location from the public IP address.",
                        "Location Unavailable",
                        JOptionPane.WARNING_MESSAGE
                    );

                } finally {

                    if (locateButton != null) {
                        locateButton.setEnabled(true);
                    }
                }
            }
        }.execute();
    }

    // SHOP CARD
    static JComponent shopCard(Shop s) {

        GradientPanel c = new GradientPanel(
            new BorderLayout(0, 8),
            GRADIENT_DARK,
            GRADIENT_LIGHT,
            16
        );

        c.setBorder(
            new CompoundBorder(
                new LineBorder(GRADIENT_BORDER, 1, true),
                new EmptyBorder(12, 14, 12, 14)
            )
        );

        c.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 135)
        );

        c.setPreferredSize(
            new Dimension(280, 125)
        );

        c.setAlignmentX(Component.LEFT_ALIGNMENT);

        // SHOP NAME
        JLabel name = lbl(
            s.name == null ? "Repair Shop" : s.name,
            15,
            true,
            Color.WHITE
        );

        name.setOpaque(false);

        // RATING AND DISTANCE
        JLabel info = lbl(
            "\u2605 " + s.rating + "     " + s.dist + " km",
            13,
            false,
            LIGHT_TEXT
        );

        info.setOpaque(false);

        // VIEW DETAILS BUTTON
        GradientButton details =
            new GradientButton("View Details");

        details.setPreferredSize(
            new Dimension(140, 32)
        );

        details.setMinimumSize(
            new Dimension(140, 32)
        );

        details.addActionListener(e -> {

            System.out.println(
                "VIEW DETAILS CLICKED: " + s.name
            );

            details.setEnabled(false);

            SwingUtilities.invokeLater(() -> {

                try {

                    ShopDetailDialog.show(s);

                } catch (Exception ex) {

                    ex.printStackTrace();

                    JOptionPane.showMessageDialog(
                        SwingUtilities.getWindowAncestor(details),
                        "Unable to open Shop Details:\n"
                            + ex.getMessage(),
                        "Shop Details Error",
                        JOptionPane.ERROR_MESSAGE
                    );

                } finally {

                    details.setEnabled(true);
                }
            });
        });

        JPanel actionPanel = new JPanel(
            new FlowLayout(FlowLayout.LEFT, 0, 0)
        );

        actionPanel.setOpaque(false);
        actionPanel.add(details);

        c.add(name, BorderLayout.NORTH);
        c.add(info, BorderLayout.CENTER);
        c.add(actionPanel, BorderLayout.SOUTH);

        return c;
    }

    // FULL PAGE GRADIENT BACKGROUND
    private static class PageGradientPanel extends JPanel {

        PageGradientPanel(LayoutManager layout) {
            super(layout);
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {

            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY
            );

            GradientPaint gradient = new GradientPaint(
                0, 0, GRADIENT_DARK,
                getWidth(), getHeight(), GRADIENT_LIGHT
            );

            g2.setPaint(gradient);

            g2.fillRect(
                0, 0,
                getWidth(),
                getHeight()
            );

            g2.dispose();
        }
    }

    // CUSTOM GRADIENT PANEL
    private static class GradientPanel extends JPanel {

        private final Color startColor;
        private final Color endColor;
        private final int arc;

        GradientPanel(
                LayoutManager layout,
                Color startColor,
                Color endColor,
                int arc) {

            super(layout);

            this.startColor = startColor;
            this.endColor = endColor;
            this.arc = arc;

            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {

            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
            );

            GradientPaint gradient = new GradientPaint(
                0,
                0,
                startColor,
                getWidth(),
                getHeight(),
                endColor
            );

            g2.setPaint(gradient);

            RoundRectangle2D rounded =
                new RoundRectangle2D.Float(
                    0,
                    0,
                    getWidth() - 1,
                    getHeight() - 1,
                    arc,
                    arc
                );

            g2.fill(rounded);

            g2.setColor(GRADIENT_BORDER);
            g2.setStroke(new BasicStroke(1.2f));
            g2.draw(rounded);

            g2.dispose();
        }
    }

    // CUSTOM GRADIENT BUTTON
    private static class GradientButton extends JButton {

        GradientButton(String text) {

            super(text);

            setFont(
                new Font("SansSerif", Font.BOLD, 12)
            );

            setForeground(Color.WHITE);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);

            setCursor(
                Cursor.getPredefinedCursor(
                    Cursor.HAND_CURSOR
                )
            );

            setPreferredSize(
                new Dimension(105, 36)
            );

            setBorder(
                new EmptyBorder(8, 16, 8, 16)
            );
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
            );

            Color topColor = GRADIENT_MID;
            Color bottomColor = GRADIENT_LIGHT;

            if (!isEnabled()) {

                topColor = new Color(55, 75, 100);
                bottomColor = new Color(35, 55, 80);

            } else if (getModel().isPressed()) {

                topColor = GRADIENT_DARK;
                bottomColor = GRADIENT_MID;

            } else if (getModel().isRollover()) {

                topColor = GRADIENT_LIGHT;
                bottomColor = new Color(25, 100, 165);
            }

            GradientPaint gradient = new GradientPaint(
                0,
                0,
                topColor,
                0,
                getHeight(),
                bottomColor
            );

            g2.setPaint(gradient);

            g2.fillRoundRect(
                0,
                0,
                getWidth(),
                getHeight(),
                12,
                12
            );

            g2.setColor(GRADIENT_BORDER);

            g2.drawRoundRect(
                0,
                0,
                getWidth() - 1,
                getHeight() - 1,
                12,
                12
            );

            g2.dispose();

            super.paintComponent(g);
        }
    }
}
